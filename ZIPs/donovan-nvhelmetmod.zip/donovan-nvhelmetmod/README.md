# Donovan Night Vision Helmet Mod

## 7 Days 2 Die Modlet

A night vision goggle that can be attached to any helmet as a mod.
While they're not generally available in normal loot, you may find them attached to Military and Swat helmets.
