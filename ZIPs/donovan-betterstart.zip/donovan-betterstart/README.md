# Donovan BetterStart

## 7 Days 2 Die Modlet

- Removes the starting quests, just make a bedroll and get going.
- Doubles the skill points you get from the starter quests (8).
- Gives you some starting items
  - 500 Dukes
  - 500 Stone
  - 500 Wood
  - 1 Stone Axe
  - 1 Stone Shovel
  - 1 Bone Knife
  - Padded Armor bundle
  - 1 Helmet Light
