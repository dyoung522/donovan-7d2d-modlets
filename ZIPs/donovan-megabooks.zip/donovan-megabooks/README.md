# Donovan MegaBooks

## 7 Days 2 Die Modlet

Books are rather scarce, especially in book piles. This modlet greatly increases your chances of finding books in the world.

Includes

- Perk Books
- Schematics
- Skill Magazines
