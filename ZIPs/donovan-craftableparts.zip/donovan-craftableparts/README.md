# Donovan CraftableParts

## 7 Days 2 Die Modlet

Craftable armor and weapon parts!

Creates recipes for all weapon and armor parts so you can now craft them in the workbench.
