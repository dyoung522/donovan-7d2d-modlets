# Donovan Pick Me Up

## 7 Days 2 Die Modlet

This modlet enabled certain blocks to be picked up after being placed.

Modified blocks are:

- Wood Spikes
- Iron Spikes
- Barbed Fence
