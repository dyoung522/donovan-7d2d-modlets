# Donovan BetterBrawler

## 7 Days 2 Die Modlet

Fist weapons now do more damage which scales higher with the Brawler Perk
