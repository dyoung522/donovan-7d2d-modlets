# Donovan BetterBatons

## 7 Days 2 Die Modlet

Batons now do significantly more damage, making them more viable for end-game.

Affects the following weapons:

- Pipe Batons
- Stun Batons
