# Donovan Craftable Dukes

## 7 Days 2 Die Modlet

Craft dukes in the forge (brass + iron) -- not as profitable as selling the brass outright, but it's a nice option to have.
