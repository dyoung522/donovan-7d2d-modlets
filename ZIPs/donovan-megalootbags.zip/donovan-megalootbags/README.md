# Donovan MegaLootbags

## 7 Days 2 Die Modlet

Dramatically increases the drop rate on zombie loot bags: 20% for normal, 50% for feral, and 80% for irradiated.

### Notes

Conflicts with [MoreLootbags](https://github.com/DonovanMods/donovan-7d2d-modlets/tree/master/donovan-morelootbags)
Works well in conjunction with [LongerLootbags](https://github.com/DonovanMods/donovan-7d2d-modlets/tree/master/donovan-longerlootbags) (for those long horde nights).
