# Donovan BetterTraps

## 7 Days 2 Die Modlet

- Blade Traps and Electric Fences now have higher durability
- Blade Traps do slightly more damage.
- Blade Traps moved to T2 unlock (up to 50, from 25)
