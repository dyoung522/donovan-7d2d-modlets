# Donovan BetterBuffs

## 7 Days 2 Die Modlet

Tweaks the hunger and thirst triggers to be more realistic.
