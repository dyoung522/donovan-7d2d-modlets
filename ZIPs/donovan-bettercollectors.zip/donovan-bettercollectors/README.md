# Donovan BetterCollectors

## 7 Days 2 Die Modlet

This modlet improves the dew collectors

Note that this modlet is NOT compatible with EAC

### Pros

- Creates 2x more water (6)
- 2x faster water production (3x faster when foggy & 5x faster when raining)
- Adds a craftable Water Filter

### Cons

- No longer functions when below freezing

## Additional Credits

- ["Rain Collectors" mod by khzmusik](https://gitlab.com/karlgiesing/7d2d-a21-modlets) - adds missing functionality for Dew Collectors
