# Donovan All In One

## 7 Days 2 Die Modlet

If you were wondering which modlets use should use for the "best" experience, look no further. Here you go!
This includes all the functionality from my recommended modlets, compiled into a single modlet.

You're still welcome to pick and choose additional modlets to use, of course, but this serves as a one-stop-shop for the included modelets.

Note that this modlet is NOT compatible with EAC

### Modlets Included

- BetterBatons
- BetterBlades
- BetterBrawler
- BetterBridges
- BetterBuffs
- BetterCement
- BetterDyes
- BetterPowertools
- BetterTraps
- BetterVehicles
- LessGrind
- LongerLootbags
- MegaStacks
- MoreBooks
- MoreLootbags
- MorePerks
- NVHelmetMod
- PickMeUp

## Additional Credits

- ["Rain Collectors" mod by khzmusik](https://gitlab.com/karlgiesing/7d2d-a21-modlets) in order to add additional functionality for Dew Collectors
