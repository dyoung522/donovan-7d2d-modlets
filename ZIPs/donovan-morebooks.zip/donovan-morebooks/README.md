# Donovan MoreBooks

## 7 Days 2 Die Modlet

Books can be rather scarce, especially in book piles. This modlet increases your chances of finding books in shelves and in book piles.

Includes

- Perk Books
- Schematics
- Skill Magazines
