# Donovan BetterBlades

## 7 Days 2 Die Modlet

Bladed weapons now do significantly more damage, making them more viable for end-game.

Affects the following weapons:

- Knives
- Machetes
- Spears
- Fireaxes

Additionally, Spears and Axes can now be used to butcher animals
